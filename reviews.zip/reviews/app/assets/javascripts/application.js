//= require jquery
//= require jquery_ujs
//= require rails-ujs
//= require bootstrap
//= require turbolinks
//= require jquery.raty
//= require ratyrate
//= require_tree .
